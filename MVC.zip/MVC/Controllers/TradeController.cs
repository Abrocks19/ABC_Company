﻿using MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace MVC.Controllers
{
    public class TradeController : Controller
    {
        public static List<SelectListItem> CompanyList = null;
        // GET: Trade
        public ActionResult Index()
        {
            IEnumerable<TradeModel> trdList;
            HttpResponseMessage response = GlobalVariables.WebApiClient.GetAsync("Trades").Result;
            trdList = response.Content.ReadAsAsync<IEnumerable<TradeModel>>().Result;
            
            return View(trdList);
        }

        public ActionResult Add(int id = 0)
        {
            IEnumerable<CompanyModel> comList;
            HttpResponseMessage response1 = GlobalVariables.WebApiClient.GetAsync("Company").Result;
            comList = response1.Content.ReadAsAsync<IEnumerable<CompanyModel>>().Result;


            CompanyList = (from p in comList.AsEnumerable()
                                                 select new SelectListItem
                                                 {
                                                     Text = p.Name,
                                                     Value = p.Id.ToString()
                                                 }).ToList();
          
            ViewBag.ListItem = CompanyList;
            return View(new TradeModel());
        }

        [HttpPost]
        public ActionResult Add(TradeModel tradeModel)
        {
            SelectListItem selectedBuyer = CompanyList.Find(p => p.Value == tradeModel.Buyer);
            SelectListItem selectedSeller = CompanyList.Find(p => p.Value == tradeModel.Seller);

            tradeModel.Buyer = selectedBuyer.Text;
            tradeModel.Seller = selectedSeller.Text;

            HttpResponseMessage response = GlobalVariables.WebApiClient.PostAsJsonAsync("Trades", tradeModel).Result;
            TempData["SuccessMessage"] = "Saved Successfully";

            return RedirectToAction("Index");           
        }
    }
}