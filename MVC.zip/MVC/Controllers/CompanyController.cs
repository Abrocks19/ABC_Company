﻿using MVC.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace MVC.Controllers
{
    public class CompanyController : Controller
    {
        // GET: Company
        public ActionResult Index()
        {
           
            IEnumerable<CompanyModel> comList;
            HttpResponseMessage response = GlobalVariables.WebApiClient.GetAsync("Company").Result;
            comList = response.Content.ReadAsAsync<IEnumerable<CompanyModel>>().Result;
                        
            return View(comList);
        }

        public ActionResult Add(int id = 0)
        {           
            return View(new CompanyModel());
        }

        [HttpPost]
        public ActionResult Add(CompanyModel companyModel)
        {
            HttpResponseMessage response = GlobalVariables.WebApiClient.PostAsJsonAsync("Company", companyModel).Result;
            if (response.StatusCode == HttpStatusCode.Created)
            {
                TempData["SuccessMessage"] = "Saved Successfully";
            }
            else if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                TempData["CompanyExists"] = "Company already exists";
            }

            return RedirectToAction("Index");
        }
    }
}