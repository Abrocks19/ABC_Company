﻿using MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace MVC.Controllers
{
    public class ExportImportController : Controller
    {
        // GET: ExportImport
        public ActionResult Index()
        {
            IEnumerable<ExportImportModel> exportImportModels;
            HttpResponseMessage response = GlobalVariables.WebApiClient.GetAsync("exportImport").Result;
            exportImportModels = response.Content.ReadAsAsync<IEnumerable<ExportImportModel>>().Result;

            return View(exportImportModels);
        }
    }
}