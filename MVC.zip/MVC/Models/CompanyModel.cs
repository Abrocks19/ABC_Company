﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC.Models
{
    public class CompanyModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "This is the required feild")]
        public string Name { get; set; }
        [Required(ErrorMessage = "This is the required feild")]
        public string Country { get; set; }
    }
}