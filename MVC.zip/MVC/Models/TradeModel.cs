﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC.Models
{
    public class TradeModel
    {
        public int ID { get; set; }
        public string Seller { get; set; }
        public string Buyer { get; set; }

        [Required(ErrorMessage = "This is the required feild")]
        public Nullable<int> Value { get; set; }
    }
}