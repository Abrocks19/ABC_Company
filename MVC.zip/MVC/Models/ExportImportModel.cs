﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC.Models
{
    public class ExportImportModel
    {
        public string country { get; set; }
        public int Export { get; set; }
        public int Import { get; set; }
    }
}